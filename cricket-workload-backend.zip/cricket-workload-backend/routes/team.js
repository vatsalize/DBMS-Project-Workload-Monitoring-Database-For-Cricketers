const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/teamController');

router.get('/workload-summary', ctrl.getTeamWorkloadSummary);

module.exports = router;
