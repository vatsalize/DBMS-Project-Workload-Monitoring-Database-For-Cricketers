const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/alertsController');

// /alerts/high must come before /alerts to avoid route conflicts
router.get('/high', ctrl.getHighAlerts);
router.get('/',     ctrl.getAllAlerts);

module.exports = router;
