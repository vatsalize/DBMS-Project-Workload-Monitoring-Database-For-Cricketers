const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/trainingController');

router.get('/',  ctrl.getAllTrainingSessions);
router.post('/', ctrl.createTrainingSession);

module.exports = router;
