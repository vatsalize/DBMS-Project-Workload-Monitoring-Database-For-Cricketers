const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/recoveryController');

router.get('/',  ctrl.getAllRecoverySessions);
router.post('/', ctrl.createRecoverySession);

module.exports = router;
