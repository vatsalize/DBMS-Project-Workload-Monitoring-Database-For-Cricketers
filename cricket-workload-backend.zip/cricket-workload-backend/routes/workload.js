const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/workloadController');

router.get('/',  ctrl.getAllWorkload);
router.post('/', ctrl.createWorkloadRecord);

module.exports = router;
