const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/playersController');

// Advanced routes MUST be declared before /:id to avoid route conflicts
router.get('/high-risk', ctrl.getHighRiskPlayers);
router.get('/injured',   ctrl.getInjuredPlayers);

// Standard CRUD
router.get('/',     ctrl.getAllPlayers);
router.post('/',    ctrl.createPlayer);
router.put('/:id',  ctrl.updatePlayer);
router.delete('/:id', ctrl.deletePlayer);

// Player-specific workload history
router.get('/:id/workload', ctrl.getPlayerWorkload);

module.exports = router;
