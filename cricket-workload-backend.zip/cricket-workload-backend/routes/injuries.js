const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/injuriesController');

router.get('/',  ctrl.getAllInjuries);
router.post('/', ctrl.createInjury);

module.exports = router;
