const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/matchesController');

router.get('/',  ctrl.getAllMatches);
router.post('/', ctrl.createMatch);

module.exports = router;
