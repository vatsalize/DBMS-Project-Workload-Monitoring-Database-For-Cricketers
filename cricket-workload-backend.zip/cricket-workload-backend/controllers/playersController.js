const db = require('../db');

// GET /players  — list all players
async function getAllPlayers(req, res) {
  try {
    const [rows] = await db.query(
      'SELECT * FROM Players ORDER BY full_name'
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// POST /players  — create a player
async function createPlayer(req, res) {
  const {
    full_name, date_of_birth, role,
    batting_style, bowling_style, status,
    jersey_number, ipl_team
  } = req.body;

  // Required field validation
  if (!full_name || !date_of_birth || !role || !batting_style || !jersey_number) {
    return res.status(400).json({
      error: 'Required fields: full_name, date_of_birth, role, batting_style, jersey_number'
    });
  }

  const validRoles   = ['Batsman', 'Bowler', 'All-Rounder', 'Wicket-Keeper'];
  const validBatting = ['Right-Hand', 'Left-Hand'];
  const validStatus  = ['Active', 'Injured', 'Resting', 'Retired'];

  if (!validRoles.includes(role))
    return res.status(400).json({ error: `role must be one of: ${validRoles.join(', ')}` });
  if (!validBatting.includes(batting_style))
    return res.status(400).json({ error: `batting_style must be one of: ${validBatting.join(', ')}` });
  if (status && !validStatus.includes(status))
    return res.status(400).json({ error: `status must be one of: ${validStatus.join(', ')}` });

  try {
    const [result] = await db.query(
      `INSERT INTO Players
         (full_name, date_of_birth, role, batting_style, bowling_style, status, jersey_number, ipl_team)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [full_name, date_of_birth, role, batting_style,
       bowling_style || null, status || 'Active', jersey_number, ipl_team || null]
    );
    res.status(201).json({ message: 'Player created', player_id: result.insertId });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY')
      return res.status(409).json({ error: 'jersey_number already exists' });
    res.status(500).json({ error: err.message });
  }
}

// PUT /players/:id  — update a player
async function updatePlayer(req, res) {
  const { id } = req.params;
  const {
    full_name, date_of_birth, role,
    batting_style, bowling_style, status,
    jersey_number, ipl_team
  } = req.body;

  if (!full_name || !date_of_birth || !role || !batting_style || !jersey_number) {
    return res.status(400).json({
      error: 'Required fields: full_name, date_of_birth, role, batting_style, jersey_number'
    });
  }

  try {
    const [result] = await db.query(
      `UPDATE Players SET
         full_name=?, date_of_birth=?, role=?, batting_style=?,
         bowling_style=?, status=?, jersey_number=?, ipl_team=?
       WHERE player_id=?`,
      [full_name, date_of_birth, role, batting_style,
       bowling_style || null, status || 'Active', jersey_number, ipl_team || null, id]
    );
    if (result.affectedRows === 0)
      return res.status(404).json({ error: 'Player not found' });
    res.json({ message: 'Player updated' });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY')
      return res.status(409).json({ error: 'jersey_number already exists' });
    res.status(500).json({ error: err.message });
  }
}

// DELETE /players/:id
async function deletePlayer(req, res) {
  const { id } = req.params;
  try {
    const [result] = await db.query(
      'DELETE FROM Players WHERE player_id = ?', [id]
    );
    if (result.affectedRows === 0)
      return res.status(404).json({ error: 'Player not found' });
    res.json({ message: 'Player deleted' });
  } catch (err) {
    // FK constraint: player has related records
    if (err.code === 'ER_ROW_IS_REFERENCED_2')
      return res.status(409).json({ error: 'Cannot delete: player has linked records' });
    res.status(500).json({ error: err.message });
  }
}

// GET /players/high-risk  — players whose total workload > 250 (threshold)
async function getHighRiskPlayers(req, res) {
  try {
    const [rows] = await db.query(
      `SELECT p.player_id, p.full_name, p.role, p.status,
              ROUND(SUM(wr.workload_score), 2) AS total_workload,
              ROUND(AVG(wr.workload_score), 2) AS avg_workload,
              COUNT(wr.record_id)              AS total_sessions
       FROM Players p
       JOIN Workload_Records wr ON p.player_id = wr.player_id
       GROUP BY p.player_id, p.full_name, p.role, p.status
       HAVING total_workload > 250
       ORDER BY total_workload DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// GET /players/:id/workload  — workload history for a single player
async function getPlayerWorkload(req, res) {
  const { id } = req.params;
  try {
    // Check player exists
    const [[player]] = await db.query(
      'SELECT player_id, full_name, role, status FROM Players WHERE player_id = ?', [id]
    );
    if (!player)
      return res.status(404).json({ error: 'Player not found' });

    const [records] = await db.query(
      `SELECT wr.record_id, wr.record_date, wr.workload_score,
              wr.source_type, wr.notes,
              m.opponent, m.format, m.venue,
              ts.session_type, ts.intensity
       FROM Workload_Records wr
       LEFT JOIN Matches m          ON wr.match_id   = m.match_id
       LEFT JOIN Training_Sessions ts ON wr.session_id = ts.session_id
       WHERE wr.player_id = ?
       ORDER BY wr.record_date DESC`,
      [id]
    );
    res.json({ player, records });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// GET /players/injured  — players with status = 'Injured'
async function getInjuredPlayers(req, res) {
  try {
    const [rows] = await db.query(
      `SELECT p.player_id, p.full_name, p.role, p.jersey_number, p.ipl_team,
              i.injury_date, i.body_part, i.injury_type, i.severity,
              i.expected_recovery_days, i.is_recovered
       FROM Players p
       LEFT JOIN Injuries i ON p.player_id = i.player_id AND i.is_recovered = 0
       WHERE p.status = 'Injured'
       ORDER BY p.full_name`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

module.exports = {
  getAllPlayers,
  createPlayer,
  updatePlayer,
  deletePlayer,
  getHighRiskPlayers,
  getPlayerWorkload,
  getInjuredPlayers
};
