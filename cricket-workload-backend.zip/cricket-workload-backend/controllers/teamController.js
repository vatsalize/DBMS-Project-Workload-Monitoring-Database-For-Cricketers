const db = require('../db');

// GET /team/workload-summary
async function getTeamWorkloadSummary(req, res) {
  try {
    const [rows] = await db.query(
      `SELECT
         p.player_id,
         p.full_name,
         p.role,
         p.status,
         p.ipl_team,
         COUNT(wr.record_id)              AS total_sessions,
         ROUND(SUM(wr.workload_score), 2) AS total_workload,
         ROUND(AVG(wr.workload_score), 2) AS avg_workload,
         ROUND(MAX(wr.workload_score), 2) AS max_workload,
         -- Risk classification mirrors fn_risk_class from SQL
         CASE
           WHEN SUM(wr.workload_score) > 300 THEN 'Critical'
           WHEN SUM(wr.workload_score) > 200 THEN 'High'
           WHEN SUM(wr.workload_score) > 100 THEN 'Moderate'
           ELSE 'Low'
         END AS risk_level,
         (SELECT COUNT(*) FROM Workload_Alerts wa
          WHERE wa.player_id = p.player_id AND wa.is_resolved = 0) AS open_alerts,
         (SELECT COUNT(*) FROM Injuries i
          WHERE i.player_id = p.player_id AND i.is_recovered = 0)  AS active_injuries
       FROM Players p
       LEFT JOIN Workload_Records wr ON p.player_id = wr.player_id
       GROUP BY p.player_id, p.full_name, p.role, p.status, p.ipl_team
       ORDER BY total_workload DESC`
    );

    // Aggregate totals
    const teamTotal = rows.reduce((sum, r) => sum + (parseFloat(r.total_workload) || 0), 0);
    const teamAvg   = rows.length ? teamTotal / rows.length : 0;

    res.json({
      team_total_workload: Math.round(teamTotal * 100) / 100,
      team_avg_workload:   Math.round(teamAvg   * 100) / 100,
      player_count: rows.length,
      players: rows
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

module.exports = { getTeamWorkloadSummary };
