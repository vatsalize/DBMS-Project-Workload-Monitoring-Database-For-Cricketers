const db = require('../db');

// GET /alerts  — all alerts
async function getAllAlerts(req, res) {
  try {
    const [rows] = await db.query(
      `SELECT wa.*, p.full_name AS player_name, p.role, p.status
       FROM Workload_Alerts wa
       JOIN Players p ON wa.player_id = p.player_id
       ORDER BY wa.alert_date DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// GET /alerts/high  — unresolved alerts only
async function getHighAlerts(req, res) {
  try {
    const [rows] = await db.query(
      `SELECT wa.alert_id, wa.alert_date, wa.alert_type, wa.alert_message,
              wa.triggered_score, wa.threshold_value, wa.is_resolved,
              p.full_name AS player_name, p.role, p.status
       FROM Workload_Alerts wa
       JOIN Players p ON wa.player_id = p.player_id
       WHERE wa.is_resolved = 0
       ORDER BY wa.alert_date DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

module.exports = { getAllAlerts, getHighAlerts };
