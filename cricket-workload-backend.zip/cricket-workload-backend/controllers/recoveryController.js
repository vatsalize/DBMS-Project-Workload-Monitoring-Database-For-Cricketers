const db = require('../db');

// GET /recovery
async function getAllRecoverySessions(req, res) {
  try {
    const [rows] = await db.query(
      `SELECT rs.*, p.full_name AS player_name,
              i.body_part, i.injury_type, i.severity
       FROM Recovery_Sessions rs
       JOIN Players p       ON rs.player_id = p.player_id
       LEFT JOIN Injuries i ON rs.injury_id = i.injury_id
       ORDER BY rs.session_date DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// POST /recovery
async function createRecoverySession(req, res) {
  const {
    player_id, injury_id, session_date, recovery_type,
    duration_mins, pain_level, recovery_score, conducted_by
  } = req.body;

  if (!player_id || !session_date || !recovery_type || !duration_mins)
    return res.status(400).json({
      error: 'Required fields: player_id, session_date, recovery_type, duration_mins'
    });

  const validTypes = [
    'Physiotherapy', 'Ice Bath', 'Rest', 'Yoga',
    'Pool Session', 'Massage', 'Gym Rehab', 'Stretching'
  ];
  if (!validTypes.includes(recovery_type))
    return res.status(400).json({ error: `recovery_type must be one of: ${validTypes.join(', ')}` });
  if (duration_mins < 10 || duration_mins > 300)
    return res.status(400).json({ error: 'duration_mins must be between 10 and 300' });
  if (pain_level !== undefined && pain_level !== null && (pain_level < 0 || pain_level > 10))
    return res.status(400).json({ error: 'pain_level must be between 0 and 10' });

  try {
    const [r] = await db.query(
      `INSERT INTO Recovery_Sessions
         (player_id, injury_id, session_date, recovery_type, duration_mins,
          pain_level, recovery_score, conducted_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [player_id, injury_id || null, session_date, recovery_type, duration_mins,
       pain_level !== undefined ? pain_level : null,
       recovery_score || null, conducted_by || null]
    );
    res.status(201).json({ message: 'Recovery session created', recovery_id: r.insertId });
  } catch (err) {
    if (err.code === 'ER_NO_REFERENCED_ROW_2')
      return res.status(404).json({ error: 'player_id or injury_id does not exist' });
    res.status(500).json({ error: err.message });
  }
}

module.exports = { getAllRecoverySessions, createRecoverySession };
