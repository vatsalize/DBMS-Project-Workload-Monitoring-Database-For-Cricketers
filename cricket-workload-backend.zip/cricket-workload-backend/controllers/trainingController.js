const db = require('../db');

// GET /training
async function getAllTrainingSessions(req, res) {
  try {
    const [rows] = await db.query(
      `SELECT ts.*, c.full_name AS coach_name, c.specialization
       FROM Training_Sessions ts
       JOIN Coaches c ON ts.coach_id = c.coach_id
       ORDER BY ts.session_date DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// POST /training
async function createTrainingSession(req, res) {
  const { coach_id, session_date, session_type, duration_mins, intensity, location, notes } = req.body;

  if (!coach_id || !session_date || !session_type || !duration_mins || !intensity || !location)
    return res.status(400).json({
      error: 'Required fields: coach_id, session_date, session_type, duration_mins, intensity, location'
    });

  const validTypes     = ['Batting', 'Bowling', 'Fielding', 'Fitness', 'Recovery', 'Tactical'];
  const validIntensity = ['Low', 'Moderate', 'High', 'Very High'];

  if (!validTypes.includes(session_type))
    return res.status(400).json({ error: `session_type must be one of: ${validTypes.join(', ')}` });
  if (!validIntensity.includes(intensity))
    return res.status(400).json({ error: `intensity must be one of: ${validIntensity.join(', ')}` });
  if (duration_mins < 15 || duration_mins > 480)
    return res.status(400).json({ error: 'duration_mins must be between 15 and 480' });

  try {
    const [r] = await db.query(
      `INSERT INTO Training_Sessions
         (coach_id, session_date, session_type, duration_mins, intensity, location, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [coach_id, session_date, session_type, duration_mins, intensity, location, notes || null]
    );
    res.status(201).json({ message: 'Training session created', session_id: r.insertId });
  } catch (err) {
    if (err.code === 'ER_NO_REFERENCED_ROW_2')
      return res.status(404).json({ error: 'coach_id does not exist' });
    res.status(500).json({ error: err.message });
  }
}

module.exports = { getAllTrainingSessions, createTrainingSession };
