const db = require('../db');

// GET /matches
async function getAllMatches(req, res) {
  try {
    const [rows] = await db.query(
      'SELECT * FROM Matches ORDER BY match_date DESC'
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// POST /matches
async function createMatch(req, res) {
  const { match_date, opponent, venue, format, result, total_overs } = req.body;

  if (!match_date || !opponent || !venue || !format)
    return res.status(400).json({ error: 'Required fields: match_date, opponent, venue, format' });

  const validFormats = ['Test', 'ODI', 'T20I'];
  const validResults = ['Won', 'Lost', 'Draw', 'No Result', 'Tied'];

  if (!validFormats.includes(format))
    return res.status(400).json({ error: `format must be one of: ${validFormats.join(', ')}` });
  if (result && !validResults.includes(result))
    return res.status(400).json({ error: `result must be one of: ${validResults.join(', ')}` });
  if (total_overs !== undefined && total_overs !== null && total_overs <= 0)
    return res.status(400).json({ error: 'total_overs must be greater than 0' });

  try {
    const [r] = await db.query(
      `INSERT INTO Matches (match_date, opponent, venue, format, result, total_overs)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [match_date, opponent, venue, format, result || null, total_overs || null]
    );
    res.status(201).json({ message: 'Match created', match_id: r.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

module.exports = { getAllMatches, createMatch };
