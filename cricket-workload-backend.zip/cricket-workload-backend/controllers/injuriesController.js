const db = require('../db');

// GET /injuries
async function getAllInjuries(req, res) {
  try {
    const [rows] = await db.query(
      `SELECT i.*, p.full_name AS player_name, p.role
       FROM Injuries i
       JOIN Players p ON i.player_id = p.player_id
       ORDER BY i.injury_date DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// POST /injuries
async function createInjury(req, res) {
  const {
    player_id, injury_date, body_part, injury_type,
    severity, expected_recovery_days, actual_recovery_days,
    is_recovered, notes
  } = req.body;

  if (!player_id || !injury_date || !body_part || !injury_type || !severity)
    return res.status(400).json({
      error: 'Required fields: player_id, injury_date, body_part, injury_type, severity'
    });

  const validSeverity = ['Mild', 'Moderate', 'Severe', 'Critical'];
  if (!validSeverity.includes(severity))
    return res.status(400).json({ error: `severity must be one of: ${validSeverity.join(', ')}` });

  try {
    const [r] = await db.query(
      `INSERT INTO Injuries
         (player_id, injury_date, body_part, injury_type, severity,
          expected_recovery_days, actual_recovery_days, is_recovered, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [player_id, injury_date, body_part, injury_type, severity,
       expected_recovery_days || null, actual_recovery_days || null,
       is_recovered !== undefined ? is_recovered : 0,
       notes || null]
    );
    res.status(201).json({ message: 'Injury recorded', injury_id: r.insertId });
  } catch (err) {
    if (err.code === 'ER_NO_REFERENCED_ROW_2')
      return res.status(404).json({ error: 'player_id does not exist' });
    res.status(500).json({ error: err.message });
  }
}

module.exports = { getAllInjuries, createInjury };
