const db = require('../db');

// GET /workload
async function getAllWorkload(req, res) {
  try {
    const [rows] = await db.query(
      `SELECT wr.record_id, wr.record_date, wr.workload_score, wr.source_type, wr.notes,
              p.full_name AS player_name, p.role,
              m.opponent, m.format, m.venue,
              ts.session_type, ts.intensity
       FROM Workload_Records wr
       JOIN Players p              ON wr.player_id  = p.player_id
       LEFT JOIN Matches m         ON wr.match_id   = m.match_id
       LEFT JOIN Training_Sessions ts ON wr.session_id = ts.session_id
       ORDER BY wr.record_date DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// POST /workload
async function createWorkloadRecord(req, res) {
  const { player_id, match_id, session_id, record_date, workload_score, source_type, notes } = req.body;

  if (!player_id || !record_date || workload_score === undefined || !source_type)
    return res.status(400).json({
      error: 'Required fields: player_id, record_date, workload_score, source_type'
    });

  const validSources = ['Match', 'Training'];
  if (!validSources.includes(source_type))
    return res.status(400).json({ error: `source_type must be one of: ${validSources.join(', ')}` });
  if (workload_score < 0)
    return res.status(400).json({ error: 'workload_score must be >= 0' });

  // Business rule: source_type must match the supplied FK
  if (source_type === 'Match' && !match_id)
    return res.status(400).json({ error: 'match_id is required when source_type is Match' });
  if (source_type === 'Training' && !session_id)
    return res.status(400).json({ error: 'session_id is required when source_type is Training' });

  try {
    const [r] = await db.query(
      `INSERT INTO Workload_Records
         (player_id, match_id, session_id, record_date, workload_score, source_type, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [player_id, match_id || null, session_id || null,
       record_date, workload_score, source_type, notes || null]
    );
    res.status(201).json({ message: 'Workload record created', record_id: r.insertId });
  } catch (err) {
    if (err.code === 'ER_NO_REFERENCED_ROW_2')
      return res.status(404).json({ error: 'player_id, match_id or session_id does not exist' });
    res.status(500).json({ error: err.message });
  }
}

module.exports = { getAllWorkload, createWorkloadRecord };
