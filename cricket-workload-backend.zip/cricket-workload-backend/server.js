require('dotenv').config();
const express = require('express');
const app     = express();
const cors = require('cors');
app.use(cors());
// ── Middleware ────────────────────────────────────────────────
app.use(express.json());

// ── Routes ────────────────────────────────────────────────────
app.use('/players',  require('./routes/players'));
app.use('/matches',  require('./routes/matches'));
app.use('/training', require('./routes/training'));
app.use('/workload', require('./routes/workload'));
app.use('/injuries', require('./routes/injuries'));
app.use('/recovery', require('./routes/recovery'));
app.use('/alerts',   require('./routes/alerts'));
app.use('/team',     require('./routes/team'));

// ── Health check ──────────────────────────────────────────────
app.get('/', (_req, res) => {
  res.json({ message: 'Cricket Workload API is running 🏏' });
});

// ── 404 handler ───────────────────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// ── Global error handler ──────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error', details: err.message });
});

// ── Start server ──────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀  Server running on http://localhost:${PORT}`);
});
